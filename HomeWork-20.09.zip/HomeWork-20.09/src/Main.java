import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
/*                  Задание 1.
Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
В методе умножения 4-х чисел – вызов метода для 3-х чисел.          */

        System.out.println(multiply(5, 6)); // Вызов метода для двух чисел
        System.out.println(multiply(2.0, 3.0, 4.0)); // Вызов метода для трех чисел
        System.out.println(multiply(1.0, 2.0, 3.0)); // Вызов метода для четырех чисел
    }

    // Метод для умножения двух чисел
    public static double multiply(double a, double b) {
        return a * b;
    }

    // Метод для умножения трех чисел, использует метод для двух чисел
    public static double multiply(double a, double b, double c) {
        return multiply(a, b) * c;
    }
}

class Main1 {
    /*
    Создайте массив из 8 случайных целых чисел из интервала [1;50]
    Выведите массив на консоль в строку.
    Замените каждый элемент с нечетным индексом на ноль.
    Снова выведете массив на консоль в отдельной строке.
    Отсортируйте массив по возрастанию.
    Снова выведете массив на консоль в отдельной строке.
    */
    public static void main(String[] args) {

        Random random = new Random();

        int[] array = new int[8];

        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(50) + 1;
        }

        System.out.println("Исходный массив: " + Arrays.toString(array));

        // Заменить элементы с нечетными индексами на 0
        for (int i = 1; i < array.length; i += 2) {
            array[i] = 0;
        }
        System.out.println("Массив после замены элементов с нечетными " +
                "индексами: " + Arrays.toString(array));
        // Отсортировать массив по возрастанию
        Arrays.sort(array);
        System.out.println("Отсортированный массив: " + Arrays.toString(array));
    }
}

class Mass {
    /*
    Создайте массив из 5 строк.
    Используя метод length() строк, найдите строку с наибольшей длиной и строк с наименьшей длиной.
    Выведите массив и полученный строки в консоль.
    */
    public static void main(String[] args) {
        String[] array = {
                "Это пример строки",
                "Еще одна строка с большим количеством слов",
                "Короткая строка",
                "Еще одна длинная цепочка",
                "Последняя строка в массиве"
        };

        int maxLengthIndex = 0;
        int minLengthIndex = 0;

        for (int i = 1; i < array.length; i++) {
            if (array[i].length() > array[maxLengthIndex].length()) {
                maxLengthIndex = i;
            }

            if (array[i].length() < array[minLengthIndex].length()) {
                minLengthIndex = i;
            }
        }

        System.out.println(Arrays.toString(array));
        System.out.println("Строка с наибольшей длиной: " + array[maxLengthIndex] + " и строка с наименьшей длиной: " +
                array[minLengthIndex]);
    }
}

