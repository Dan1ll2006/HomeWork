import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        //Задание 1
        /*Дана длина в метрах. Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        Выведите начальное и конвертированные значения на экран.*/

        Scanner scanner = new Scanner(System.in);
        double meter = scanner.nextDouble();
        scanner.close();

        double kilometer = meter / 1000;
        double mile = meter * 0.000621371;
        double foot = meter * 3.28084;
        int arshin = (int) (meter * 3.5);

        System.out.printf("%.2f meters = %.2f kilometers = %.2f miles = %.2f feet = %d arshins\n",
                meter, kilometer, mile, foot, arshin);
    }
}
            class Main2 {
        public static void main(String[] args){

            //Задание 2
                /*Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
                Выведите сумму сдачи в виде “X рублей и Y копеек”.*/

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите общую стоимость покупок:");
        double totalPrice = sc.nextDouble();
        System.out.println("Введите сумму, которую дал покупатель:");
        double customerMoney = sc.nextDouble();

        double change = customerMoney - totalPrice;
        System.out.println(change);
    }
}
        class Main3 {
    public static void main(String[] args){

        //Задание 3
        /*Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
        Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
        В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree),
        или тренер Кейт, если она вернётся из путешествия (hasKateComeBack).
        Вести детей может только один тренер. Если Джим и Кейт смогут вести детей вместе,
        то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
        Напишите логическое выражение для вычисления того, состоится ли поход. Подберите условия, при которых поход состоится.*/

        boolean  isGoodWeather = true; //закончится учебный год
        boolean  hasBoughtRaincoats = true; //закупит дождевики
        boolean  isJimFree = true; //тренер Джим, если он освободится
        boolean  hasKateComeBack = true; //тренер Кейт, если она вернётся из путешествия
        boolean  isYearFinished = (isGoodWeather && hasBoughtRaincoats && (isJimFree || hasKateComeBack));
        System.out.println(isYearFinished);
    }
}
            class Main4{
        public static void main(String[] args){
                //Задание 4
            /*Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
            Остаток деления можно отбросить.
            Операторы деления / и остатка от деления % применять нельзя*/

        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите целое число: ");
            int number = scanner.nextInt();

            int result = number / 2;
        System.out.println(result);
    }
}