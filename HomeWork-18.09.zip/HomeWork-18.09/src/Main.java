import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) {
        /*Напиши программу, которая моделирует ситуацию.
        Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        Каждый друг случайным образом может подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов.
        Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
        Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!*/

        Random rand = new Random();
        int totalDonation = 0;

        System.out.println("Привет! Спасибо, что помогаете мне собрать деньги " +
                "на новый игровой компьютер!");

        while (totalDonation < 10_000) {
            int newDonation = rand.nextInt(4) * 50 + 50;
            totalDonation += newDonation;

            System.out.printf("Спасибо %s, вы дали мне $%d!%n",
                    getNameOfFriend(rand.nextInt(5)), newDonation);

            if (totalDonation >= 10_000) {
                System.out.println("Отлично, необходимая сумма собрана!");
                break;
            }
        }

        if (totalDonation < 10_000) {
            System.out.println("Не хватает денег...");
        } else {
            System.out.format("Мы собрали $%d, пойдемте выпьем" + " за мое здоровье!%n", totalDonation);
        }
    }

    private static String getNameOfFriend(int index) {
        String[] friends = {
                "Вася", "Петя", "Коля", "Дима", "Миша"
        };

        return friends[index % friends.length];
    }
}
    /*Используйте foreach.
    Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
    Программа должна вывести все дни недели, кроме данного.*/
    class Main2 {
        enum Days
        {
            Понедельник, Вторник, Среда, Четверг, Пятница, Суббота, Воскресенье;
        }

        public static void main (String[] args){
            List<Days> days = Arrays.asList(Days.values());
            System.out.print("Введите день недели, который не является текущим: ");
            Scanner scan = new Scanner (System.in);
            String userInput = scan.next();
            scan.close();

            days.stream()
                    .filter(day -> !day.toString().equalsIgnoreCase(userInput))
                    .forEach(day -> System.out.print(day.toString() + ", "));

            System.out.println();
        }
    }