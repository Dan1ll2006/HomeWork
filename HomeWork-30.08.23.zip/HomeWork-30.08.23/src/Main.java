import java.util.concurrent.atomic.AtomicInteger;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //Задание 1
    String MyChar;
            MyChar = "G";
        System.out.println(MyChar);
    byte MyByte;
            MyByte = 4;
        System.out.println(MyByte);
    int MyInt;
            MyInt = 89;
        System.out.println(MyInt);
    short MyShort;
            MyShort = 56;
        System.out.println(MyShort);
    float MyFloat;
            MyFloat = 4.7333436F;
        System.out.println(MyFloat);
    double MyDouble;
            MyDouble = 4.355453532;
        System.out.println(MyDouble);
    long MyLong;
            MyLong = 12_121;
        System.out.println(MyLong);

        //Задание 2
        int a = 345;
        float r1;
        float r2;
        float r3;
        r1 = (float) (a / 1.15);
        r2 = (float) (a / 7.6666666667);
        r3 = (float) (a / 69);
        System.out.println("результат, число " + a + " равно => " + r1 + "," + r2 + "," + r3);

    }

}