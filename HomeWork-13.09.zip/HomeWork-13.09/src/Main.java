import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

/*              Задание 1.
Пользователь вводит, сколько лет он состоит в браке.
Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей (бумажная, ситцевая, чугунная, серебряная и.д.).
Не обязательно указывать все годовщины, достаточно 10-15                    */


        Scanner sc = new Scanner(System.in);
        System.out.println("Введите количество лет, в течение которых вы были женаты:");
        int yearsMarried = sc.nextInt();
        System.out.println();

        switch (yearsMarried) {
            case 1:
                System.out.println("Поздравляю! Ваша Бумажная годовщина свадьбы не за горами");
                break;
            case 2:
                System.out.println("Поздравляю! Ваша Кожаная годовщина свадьбы не за горами! ");
                break;
            case 3:
                System.out.println("Поздравляю! Ваша Льняная годовщина свадьбы не за горами! ");
                break;
            case 4:
                System.out.println("Поздравляю! Ваша Деревянная свадьбы не за горами! ");
                break;
            case 5:
                System.out.println("Поздравляю!Ваша Чугунная годовщина свадьбы не за горами! ");
                break;
            case 6:
                System.out.println("Поздравляю! Ваша Медная годовщина свадьбы не за горами! ");
                break;
            case 7:
                System.out.println("Поздравляю! Ваша Жестяная (Шерстяная) годовщина свадьбы не за горами! ");
                break;
            case 8:
                System.out.println("Поздравляю! Ваша Фаянсовая (ромашковая) годовщина свадьбы не за горами! ");
                break;
            case 9:
                System.out.println("Поздравляю! Ваша Оловянная годовщина свадьбы не за горами! ");
                break;
            case 10:
                System.out.println("Поздравляю! Ваша Стальная годовщина свадьбы не за горами! ");
                break;
            default:
                System.out.println(yearsMarried + "Годовой юбилей");
                break;
        }
    }
}

class Game {
/*                  Задание 2.
    Напишите консольную игру «Камень, ножницы, бумага».
    Пользователь вводит свой выбор (в виде строки или числа).
    Программа случайным образом делает свой выбор и выводит на экран.
    Далее программа показывает, кто победитель – пользователь или программа.            */
    private static final int MAX_TRIES = 3;
    private static Scanner scanner = new Scanner(System.in);
    private static Random Random = new Random();

    public static void main(String[] args) {
        Game game = new Game();
        game.play(MAX_TRIES);
    }

    private void play(int maxTries) {
        while (maxTries > 0) {
            String userChoice = getUserChoice();
            System.out.println();
            if (checkResult(userChoice)) {
                maxTries--;
            } else {
                System.out.println("Ты проиграл :(");
            }
        }
        System.out.println("Ты победил!");
    }

    private String getUserChoice() {
        System.out.println("Выберите 1 для камня, 2 для бумаги, 3 для ножниц");
        return scanner.nextLine().trim();
    }
    private boolean checkResult(String userChoice) {
        int userChoiceAsInt = Integer.valueOf(userChoice);
        int computerChoice = Random.nextInt(3) + 1;
        String result =" ";

        if (userChoiceAsInt == computerChoice) {
            result = "Это ничья!";
        } else if (userChoiceAsInt == 1 && computerChoice == 2) {
            result = "Ты проиграл! Камень ломает ножницы.";
        } else if (userChoiceAsInt == 2 && computerChoice == 3) {
            result = "Ты проиграл! Бумага покрывает камень.";
        } else if (userChoiceAsInt == 3 && computerChoice == 1) {
            result = "Ты победил! Ножницы режут бумагу.";
        }

        return !result.equals("Это ничья!");
    }
}