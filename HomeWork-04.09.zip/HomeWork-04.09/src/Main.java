import org.w3c.dom.ls.LSOutput;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
                                Задание 1
    1 Напишите программу, в которой объявите переменные всех примитивных типов.
    Значение для каждой переменной сгенерируйте с помощью класса Random.
    При необходимости используйте приведение типов. Полученные значения выведите в консоль.
    2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
    При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет.
    Полученное значение выведите в консоль.                 */
        Random rd = new Random();
        byte rB = (byte) rd.nextInt();
        short s = (short) rd.nextInt(Short.MAX_VALUE + 1);
        int i = rd.nextInt();
        float f = rd.nextFloat();
        char c = (char)(rd.nextInt(26) + 'a');
        long l = rd.nextLong();
        double d = rd.nextDouble();

        System.out.println(rB);
        System.out.println(s);
        System.out.println(i);
        System.out.println(f);
        System.out.println(c);
        System.out.println(l);
        System.out.println(d);

        String string = String.valueOf(0-100);
        System.out.println(string);


    }
}

class Main2 {
    /*
                    Задание 2
    Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
    Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги,
    как [Вес] килограмм золота.». В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.                 */

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Введите ваше имя: ");
    String name = scanner.nextLine();
    System.out.println("Введите ваш возраст (полных лет): ");
    int age = scanner.nextInt();
    scanner.nextLine(); // Убираем символ новой строки из ввода
    System.out.println("Введите ваш вес (килограмм): ");
    double weight = scanner.nextDouble();

    String message = String.format("Уважаемый, %s! В свои %d лет вы для нас дороги, " +
            "как %f килограмм золота.", name, age, weight);

    System.out.println(message);
}


class Main3 {
    /*
                Задание 3
    Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение), разницу (вычитание),
    произведение (умножение) и частное (деление) введённых чисел. Результат вычислений выведите в консоль.                          */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите свое имя:");
        String name = scanner.nextLine();
        System.out.println("Введите свой возраст (полные годы):");
        int age = scanner.nextInt();
        scanner.next();
        System.out.println("Введите свой вес (килограммы):");
        double weight = scanner.nextDouble();
        String message = String.format("Дорогой, в свои %d лет ты такой же драгоценный, как %f килограммов золота.");
        System.out.println(message);
    }
    }


}