import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        /* №1
    Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
    Числа могут быть, как целочисленные, так и дробные.

        Например :
        ввод : m=10.5, n=10.45
        вывод: Число 10.45 ближе к 10.*/
        Random rd = new Random();
    double m = rd.nextDouble(10.01);
    double n = rd.nextDouble(10.99);
        if (n > m) {
            System.out.println(n);
        } else {
            System.out.println(m);
        }

    }
}

class Main2 {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_WHITE = "\u001B[37m";

    public static void main(String[] args) {
    /*Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
    Пользователь сам вводит два целых однозначных числа. Программа задаёт вопрос: результат умножения первого числа на второе.
    Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
    Если пользователь ответил неправильно, то программа должна показать правильный ответ.*/

        Scanner scanner = new Scanner(System.in);
        int a, b, c;
        System.out.print(ANSI_YELLOW + "Введите первое число: ");
        a = scanner.nextInt();
        System.out.print(ANSI_YELLOW + "Введите второе число: ");
        b = scanner.nextInt();

        c = a * b;

        while (true) {
            System.out.print(ANSI_YELLOW + "Ваш ответ: ");
            double userAnswer = scanner.nextDouble();
            if (userAnswer == c) {
                System.out.println(ANSI_WHITE + "Правильно!");
                break;
            } else if (userAnswer > c) {
                System.out.println(ANSI_RED + "Ваш ответ больше, чем правильный ответ.");
            } else {
                System.out.println(ANSI_RED + "Ваш ответ меньше, чем правильный ответ.");
            }
            System.out.println(ANSI_WHITE + "Результат умножения: " + c);
        }
    }
}

class Main3 {
    public static void main(String[] args) {
    /*Элвис Пресли жил с 1935 по 1977 год.
    Используя тернарные операторы, напишите программу, в которой пользователь вводит год.
    Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
    Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
    Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»*/
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите год");
        int year = scanner.nextInt();

        if (year < 1935) {
            System.out.println("Элвис еще не родился");
        } else if (year <= 1977) {
            System.out.println("Элвис жив!");
        } else {
            System.out.println("Элвис навсегда в наших сердцах!");
        }
        scanner.close();
    }
}